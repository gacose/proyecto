//SETTING ENCONDING
var fs = require('fs');
var readableStream = fs.createReadStream('file1.txt');
var data = '';

readableStream.setEncoding('utf8');

readableStream.on('data', function(chunk) {
   data+=chunk;
});

readableStream.on('end', function() {
   console.log(data);
});
console.log(data)
