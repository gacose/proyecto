//READING FROM STREAMS
var fs = require('fs');
var readableStream = fs.createReadStream('file1.txt');
var data = '';

readableStream.on('data', function(chunk) {
    data+=chunk;
});

readableStream.on('end', function() {
  console.log(data);
});

console.log(data);



//SETTING ENCONDING
//var fs = require('fs');
//var readableStream = fs.createReadStream('file.txt');
//var data = '';

//readableStream.setEncoding('utf8');

//readableStream.on('data', function(chunk) {
//    data+=chunk;
//});

//readableStream.on('end', function() {
//    console.log(data);
//});


//PIPING
//var fs = require('fs');
//var readableStream = fs.createReadStream('file1.txt');
//var writableStream = fs.createWriteStream('file2.txt');

//readableStream.pipe(writableStream);
